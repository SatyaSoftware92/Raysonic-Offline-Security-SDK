﻿using System;
using System.Windows;

/*
 * =========================================================================
 * 🛡️ [PREMIUM FEATURE] RAYSONIC SDK INTEGRATION
 * To enable enterprise-grade security, purchase the SDK, add the DLLs to 
 * your project references, and uncomment the lines marked with [UNCOMMENT].
 * =========================================================================
 */
// [UNCOMMENT] using Raysonic.SDK;

namespace Raysonic.ClientSim
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            // Simulated application loading process
            System.Threading.Thread.Sleep(1000);

            // [STEP 1] Define your product key (This must match the Keygen)
            string clientSerialKey = "SATYA-1234-ABCD";

            try
            {
                /*
                 * [STEP 2] CORE SECURITY INITIALIZATION
                 * This single line activates the Native C++ memory shield, 
                 * blocks debuggers (dnSpy/x64dbg), and validates the offline HWID.
                 */
                // [UNCOMMENT] bool isSafe = RaysonicGuard.InitializeSecurity(clientSerialKey);

                /*
                 * [STEP 3] SAFE EXECUTION
                 * Only run the core application if the security check passes.
                 */
                // [UNCOMMENT] if (isSafe)
                // [UNCOMMENT] {
                // Application launches normally here
                base.OnStartup(e);
                // [UNCOMMENT] }
            }
            catch (Exception ex)
            {
                /*
                 * SECURITY TRIGGERED:
                 * If the license is missing/invalid, or if reverse-engineering 
                 * is detected, the SDK throws an exception and halts execution.
                 */
                MessageBox.Show(ex.Message, "Satya Heavy Industries - Security System", MessageBoxButton.OK, MessageBoxImage.Error);
                Environment.Exit(0);
            }
        }
    }
}